package com.google.mapper;

import java.util.List;

import com.google.domain.AuthVO;

public interface AuthMapper {

	public void insert(List<AuthVO> list);
}
