package com.google.service;

import com.google.domain.MemberVO;

public interface MemberService {

	public void register(MemberVO vo);
}
