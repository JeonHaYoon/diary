package com.google.domain;

import lombok.Data;

@Data
public class AuthVO {

	private String memberId;
	private String auth;
}
