package com.google.mapper;

import java.util.List;

import com.google.domain.AuthVO;

public interface AuthMapper {

	public void insertAuth(AuthVO auth); //회원권한 부여
	
	
}
