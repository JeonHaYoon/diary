package com.google.mapper;

import com.google.domain.SelectVoteVO;

public interface SelectVoteMapper {

	int Votecheck(SelectVoteVO vo);

}
